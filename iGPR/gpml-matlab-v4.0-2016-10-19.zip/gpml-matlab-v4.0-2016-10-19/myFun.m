function [f, df] = myFun(X0, x, y, sn)
if nargin == 0 
    x = [1:1:10]'; 
    y = rand(10, 1);
    X0 = [1.0 0.5 1.0 1.0];
    sn = 0.1; 
end

a = X0(1);
b = X0(2);
l  = exp(X0(3));
l2 = l * l;
sf = exp(X0(4));
sf2 = sf*sf; 
sn2 = sn*sn;

n = length(x);
U = zeros(n, n);
R = zeros(n, n); 
for i = 1 : 1 : n
    tmpDiff = repmat( x(i, :), n-i, 1) - x(i+1:end, :);
    tmpDiff = tmpDiff';
    U(i, i+1:end) = exp(-0.5*tmpDiff.^2/l2);
    R(i, i+1:end) = tmpDiff.^2; 
end
R = R + R'; 
S = sn2 * eye(n, n);
K = sf2*(U+U'+eye(n))+S;
% str = sprintf('Rank = %02d /%02d', rank(K), size(K, 1)); 
% disp(str); 
% save('./K.mat', 'K', 'x', 'y', 'X0', 'U', 'R'); 
L = chol(K, 'lower');
InvL = inv(L); 
InvK = InvL'*InvL; 
% InvK = pinv(K);
tt = diag(L); 
logDetK = 2*sum(log(tt)); 
mx = a*x+b;
Alpha = InvK*(y-mx);
f = -0.5*(y-mx)'*Alpha - 0.5*logDetK-0.5*n*log(2*pi);
df2m = [x'; ones(1, n)] * Alpha;
K0 = U+U'+eye(n);
K2f = 2*sf2*K0;
A = (Alpha*Alpha' - InvK); 
nSum = 0; 
for i = 1 : 1 : n 
    nSum = nSum + A(i, :) * K2f(:, i); 
end
df2cf = 0.5*nSum;

K2l = sf2/l2*(R.*K0);
nSum = 0; 
for i = 1 : 1 : n 
    nSum = nSum + A(i, :) * K2l(:, i); 
end
df2cL = 0.5*nSum;
df2c = [df2cL; df2cf]; 
df = [df2m; df2c]; 

%%%%%% make sure find the minimum. 
f = -f; 
df = -df; 
end

